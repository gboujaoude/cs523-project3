Project 3 README :: Justin Hall & George Boujaoude

This folder contains the compiled jar file required to run our project. Due to the sheer
amount of code and the multitude of main() methods, we have opted not to turn in the
full source code. If you would like a copy of the source we would be happy to send it.
We just felt it was easiest to compile it for you instead of providing lengthy build instructions.

To run the code, change directories into Project3/Code. From there, type the command

    java -jar cs523-project3.jar

What will happen at this point is that our code will run through all of the configuration files
found inside of Data/ConfigHolder. These are the very same config files that we used to generate
all of our data (the data files will be placed inside of Code/data during execution).

Running the jar will open up our visualizer. You are able to zoom in and out and pan around as
you watch the simulation run for each config file. Along with this, there is a slider on the
far left that allows you to adjust the time scaling factor to increase the speed that the simulation
runs at.

By default we cap each simulation to 10 minutes before we forcibly end it regardless of the outcome.
If you would like to shorten the duration for one or multiple of the tests, simply go to
Data/ConfigHolder and open each config you wish to change. You will see one entry labeled

    + max_runtime = 600

This number is measured in seconds, so you can decrease it to whichever whole integer value you
prefer.